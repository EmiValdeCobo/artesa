# CONTEXT — estado vivo del proyecto (máx. 60 líneas; actualizar al cerrar tareas)
Actualizado: 2026-11-16

## Meta y fechas
Defensas desde el 2026-11-18. Entregables: sistema funcional en GitHub, IEEE (listo en docs/Documentacion_IEEE con compilador y visor), manual de usuario, doc técnica, flujo de trabajo.

## Decisiones tomadas
- Stack: Express + Sequelize (conductor `pg`) + PostgreSQL 16; React + Vite + Tailwind (sin Next.js); JS puro.
- Lógica de negocio crítica en funciones PL/pgSQL (ver DB_MAP.md). Backend las invoca.
- Precios incluyen IVA (13%); se desglosa en la factura. (Confirmar con docente si el CCF suma IVA aparte.)
- Facturación electrónica DTE simulada (número de control, código de generación, sello simulado).
- RBAC dinámico: roles y permisos en BD; middleware `requirePermiso`.
- El Kárdex requiere `INV_VER_KARDEX`; su `costo_unitario` solo se incluye con `INV_VER_COSTOS` además del permiso de Kárdex.
- CRUD: modelos Sequelize; funciones SQL y vistas con consultas parametrizadas. Migraciones: `scripts/db.js`. Datos demo: `pnpm seed:reset` (backend/seeders, Sequelize, reemplaza los datos en una transacción, determinista con semilla fija; no toca esquema, permisos, parámetros ni schema_migrations). Los seeders SQL 001/002 se eliminaron; queda 003 (permisos).
- Conexión BD: el backend usa el rol global restringido `web_user`; `POSTGRES_USER` queda reservado para administración y migraciones.
- Sesiones: JWT en cookie `httpOnly`, `SameSite`/`secure` configurables (`secure=true` por defecto en producción), `trust proxy` en Express, login con hash dummy anti-timing attack y logout con revocación `jti` (`seguridad.tokens_revocados`).
- Migraciones/seeders: `scripts/db.js` registra nombre, checksum SHA-256, fecha y tipo en `public.schema_migrations`. Paridad 1:1 estricta entre `database/init` (Docker bootstrap) y `database/migrations` (db:migrate).
- Producción y Docker: `morgan` estructurado (`combined` en prod, silenciado en test), cookies seguras por defecto y puertos aislados en Docker Compose (`db` en `127.0.0.1` y `api` en `expose` interno sin bypass de Nginx).
- Bitácora analítica: captura IP/User-Agent en `AsyncLocalStorage` y los propaga a variables PostgreSQL mediante `withTransaction`.
- QA / Pruebas: suite automatizada en Node.js nativo (`node:test` + `supertest`, 399 pruebas activas) y lint sin errores (2 warnings previos en Caja/Compras); cubre contratos de API, FSM, anti-float, UI/UX, lógica frontend, seguridad y accesibilidad.
- UI / Frontend: diseño unificado con selector de sucursal global, paneles reactivos y paleta de marca; Dashboard, Catálogo y Reportes responsivos. Reportes abre en pestaña de tendencia de ancho completo; variación porcentual diaria está en tooltip y SVG responde al contenedor. Dashboard conserva héroe con curva horaria comparada, selector 7/14/30, agregado PostgreSQL por zona y caché 30 s privada; lista de productos pasa a tarjetas bajo 768 px; ver `docs/diseno-widget-ventas-diarias.md`.
- UX inventario y recetas: Catálogo con badge de ingredientes alineado en sub-línea, costo en 1 línea ($0.00), modal rápido de preview de receta con estética editorial clara (Alabastro/Espresso/Terracota), redirección automática al crear producto elaborado; Editor de Recetas con flujo dual (Ficha Técnica de solo lectura con % de proporción vs Constructor interactivo), skeletons cálidos (sin spinners circulares), disponibilidad operativa con selector de sucursal/cuello de botella/alerta de stock 0 y ajuste rápido de precio con precio sugerido 40% (IVA 13% incluido).
- UI compartida: encabezados siguen `Grupo del menú · sección` (Operación, Gestión, Administración); KPIs usan `Metrica` con grid responsive común. Iconos por acción en `config/iconos.js` + `BotonIcono`; `Select`/`CustomSelect` en portal; máscaras en `utils/mascaras.js` (incluye NRC y referencia de pago); paleta de series de gráficas definida globalmente en `index.css` para tema claro/oscuro. Rediseño 2026-11-17 (paso 1 aprobado por etapas): tokens nuevos (`text-h1`, `text-kpi`, `rounded-md` 8 px, `size-control-*`, `*-text` semánticos, `line-strong`, `ring-sidebar`) y revisión visual en `/_sistema` (solo dev); Terracota es la única acción principal; carga con `Skeleton`/`PuntosCarga`, nunca spinners.
- UX 2026-11-16 (2.ª iteración): tendencia de Reportes usa `GraficaTendencia.jsx` (eje USD, hoy rayado, promedio, fines de semana); paleta global de series compartida, etiquetas de extremos en el resumen y ventas equilibradas por pestaña; sidebar fija al viewport y tabla accesible del gráfico fuera del flujo para evitar scroll horizontal; Kárdex conserva filtros en URL y paginación frontend local; alertas de stock prellenan `/compras/registrar` como borrador vía `location.state` (sin proveedor habitual en API: queda por elegir); catálogo de permisos sin scroll interno. `Table.jsx` ganó `encabezado`, `clase`, `horizontal` y `minAncho` (compatibles hacia atrás).
- API CxP/Kárdex: Compras, Reportes CxP y movimientos de inventario paginan obligatoriamente (50 por defecto, máximo 100), mantienen arreglos JSON y publican metadatos en headers. Kárdex filtra en PostgreSQL; queda pendiente adaptar el frontend para solicitar páginas y leer esos headers.
- Feedback y alertas: useAlert() unificado para acciones (notificar.exito en éxito, notificarError en catch, notificar.advertencia en validaciones que bloquean, confirm modal destructivo). Toasts en z-[100] sobre modales y drawers. Errores de carga inicial/tabla y errores por campo se conservan en línea (BannerError / CampoError).
- Tablas y paginación (2026-11-16): Table.jsx ahora ordena y pagina por defecto (10 filas, selector 10/25/50/100 con Select/CustomSelect, aria-sort y aria-live; paginacion={false} para diálogos). Comparadores en utils/tabla.js ordenan sobre el total de filas: dinero/NUMERIC como strings sin float, texto con Intl.Collator en español y nulos al final. Tablas migradas en toda la app; solo el editor de recetas permanece manual por inputs en línea.
- Rendimiento (2026-11-17): Table memoriza ordenamiento del cliente; KDS pausa polling en pestañas ocultas y agrupa cada cola en una pasada. Migración 015 / init 16 agrega índices de detalle por orden y cola POS activa; revisar EXPLAIN con datos reales antes de sumar más índices.


## Estado por módulo
| Módulo | BD | Backend | Frontend |
|---|---|---|---|
| auth / seguridad | listo | login, CRUD RBAC, usuarios y API /bitacora con métricas y severidad | Bitácora con filtros (severidad), analítica, roles (ADMIN solo lectura) y captura 409 |
| inventario | listo | CRUD unidades/insumos/productos, stock, mermas, alertas y Kárdex; cantidades físicas recibidas por API (recetas, movimientos, mermas y stock mínimo) validadas como enteros positivos | Existencias/kárdex por sucursal; catálogos con control de estado y eliminación diferenciados, filtros Todos/Activos/Inactivos y alertas de recetas |
| pos | listo | cola de preparación, órdenes (T02), ventas (T17), anulación (`fn_anular_venta`) y clientes CCF (T18) | catálogo, carrito, clientes CCF, historial de ventas, cobro mixto (T19), ticket (T46) y KDS con drag-and-drop optimista (Pointer Events) |
| caja | listo | turnos, movimientos, cierre y cuadre (T05/T06/T22) con tolerancia configurable | pantalla de caja integrada desde develop |
| compras | listo | T30 proveedores con formatos salvadoreños; T31 valida cantidades enteras, fechas en rango y total positivo, CONTADO registra pago EFECTIVO en la misma transacción; T32 pagos/CxP; T33 registro backend GASTO | Proveedores y facturas COSTO/GASTO; historial CxP por estado, gastos operativos con filtros y total pagado |
| rrhh | listo | CRUD de puestos/empleados y planillas mensuales, cálculo SQL, PDFs y permisos; pendiente extensión fiscal anual | pantallas de puestos/empleados pendientes |
| reportes | vistas listas + consultas de método de pago, cuadre y CxP | ventas diarias, top productos, métodos de pago, alertas, margen, cuadre y CxP; alcance por `id_sucursal` | panel con tendencias, comparativos, tablas paginadas y exportación CSV/PDF |
| empresa | listo | CRUD sucursales (alta asigna a todos los ADMIN activos) y apertura `/sucursales/:id/apertura` (stock mínimo + carga INVENTARIO_INICIAL); edición parámetros | sucursales con diálogo de apertura confirmado y parámetros con máscara por tipo |

Pantallas de gestión pendientes: puestos/empleados y planillas en frontend. Compras permite consultar gastos por factura, estado, sucursal, abonos y saldo; el endpoint de consulta no devuelve las líneas de concepto. El reporte CxP conserva pendientes y período reciente; la ruta operativa permite pendientes/pagadas/todas y exige portal admin más COM_VER_CXP.

## Pendientes críticos
- Verificar periódicamente tramos/versiones legales de renta, ISSS, AFP e INSAFORP con Hacienda/ISSS/SSF.
- Planillas: sincronizados init 08-12; el DE 10 requiere deducción adicional del tramo II y recálculos en junio/diciembre aún no modelados.
- Asignar responsables por módulo (ver README).
- Cambiar contraseñas semilla (`Cambiar123*`) antes de desplegar.
