import { useCallback, useEffect, useMemo, useState } from 'react';
import { AlertTriangle, Building2, CreditCard, FileText, Search } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.jsx';
import { useAlert } from '../../components/feedback/AlertProvider.jsx';
import EstadoVacio from '../../components/feedback/EstadoVacio.jsx';
import BannerError from '../../components/feedback/BannerError.jsx';
import EstadoBadge from '../../components/feedback/EstadoBadge.jsx';
import Dialogo from '../../components/Dialogo.jsx';
import EncabezadoPagina from '../../components/display/EncabezadoPagina.jsx';
import Metrica from '../../components/display/Metrica.jsx';
import { BotonIcono, Button, Card, Select, Table } from '../../components/ui/index.js';
import { listarCuentasPorPagar, registrarPago } from './comprasApi.js';

const dinero = (valor) => `$${String(valor ?? '0.00')}`;
const ESTADOS = [
  { valor: 'pendientes', texto: 'Pendientes' },
  { valor: 'pagadas', texto: 'Pagadas' },
  { valor: 'todas', texto: 'Todas' },
];

function EstadoPago({ factura }) {
  if (factura.estado_pago === 'PAGADO') return <EstadoBadge tipo="exito">Pagada</EstadoBadge>;
  if (Number(factura.dias_vencida) > 0) return <EstadoBadge tipo="error">Vencida · {factura.dias_vencida} d</EstadoBadge>;
  if (factura.estado_pago === 'PARCIAL') return <EstadoBadge tipo="info">Pago parcial</EstadoBadge>;
  return <EstadoBadge tipo="alerta">Pendiente</EstadoBadge>;
}

function PagoDialogo({ factura, cerrar, onPagado }) {
  const { notificar, notificarError } = useAlert();
  const [monto, setMonto] = useState(factura?.saldo ?? '');
  const [metodo, setMetodo] = useState('TRANSFERENCIA');
  const [referencia, setReferencia] = useState('');
  const [guardando, setGuardando] = useState(false);

  async function enviar(evento) {
    evento.preventDefault();
    const montoNum = Number(monto);
    const saldoNum = Number(factura.saldo);
    if (!monto || isNaN(montoNum) || montoNum <= 0) {
      notificar.advertencia('Monto inválido', {
        mensaje: 'Ingresa un monto de pago mayor a $0.00.',
      });
      return;
    }
    if (montoNum > saldoNum) {
      notificar.advertencia('Monto excede el saldo', {
        mensaje: `El monto no puede superar el saldo pendiente de ${dinero(factura.saldo)}.`,
      });
      return;
    }
    setGuardando(true);
    try {
      const pago = await registrarPago(factura.id_compra, { monto, metodo, referencia: referencia.trim() || null });
      notificar.exito('Pago registrado', {
        mensaje: `Se registró el pago de ${dinero(monto)} a ${factura.proveedor}.`,
      });
      onPagado(pago);
    } catch (err) {
      notificarError(err);
    } finally {
      setGuardando(false);
    }
  }

  return (
    <Dialogo onCerrar={() => !guardando && cerrar()} tamano="sm" labelledBy="pago-titulo">
      <div className="px-6 pt-6">
        <h2 id="pago-titulo" className="text-h3">Registrar pago</h2>
        <p className="mt-1 text-body text-fg-muted">{factura.proveedor} · Factura {factura.num_factura}</p>
      </div>
      <form onSubmit={enviar}>
        <div className="space-y-4 px-6 py-5">
        <div className="rounded-md bg-muted p-3 text-body"><div className="flex justify-between"><span className="text-fg-muted">Saldo pendiente</span><strong className="tabular-nums">{dinero(factura.saldo)}</strong></div></div>
        <label className="flex flex-col text-label">Monto del pago
          <input className="input mt-1.5 h-10 text-right tabular-nums" type="number" min="0.01" step="0.01" max={factura.saldo} value={monto} onChange={(evento) => setMonto(evento.target.value)} required />
          <span className="mt-1 block text-body-sm font-normal text-fg-muted">No puede superar el saldo pendiente.</span>
        </label>
        <Select etiqueta="Método" value={metodo} onChange={(evento) => setMetodo(evento.target.value)} opciones={[
          { valor: 'EFECTIVO', texto: 'Efectivo' }, { valor: 'TRANSFERENCIA', texto: 'Transferencia' },
          { valor: 'CHEQUE', texto: 'Cheque' }, { valor: 'TARJETA', texto: 'Tarjeta' },
        ]} />
        <label className="flex flex-col text-label">Referencia <span className="font-normal text-fg-muted">(opcional)</span>
          <input className="input mt-1.5 h-10" maxLength={100} value={referencia} onChange={(evento) => setReferencia(evento.target.value)} />
        </label>
        </div>
        <div className="flex flex-col-reverse gap-2 border-t border-line px-6 py-4 sm:flex-row sm:justify-end">
          <Button variante="ghost" onClick={cerrar}>Cancelar</Button>
          <Button type="submit" icono={CreditCard} cargando={guardando}>Registrar pago</Button>
        </div>
      </form>
    </Dialogo>
  );
}

export default function CuentasPorPagarPage() {
  const { tiene, usuario } = useAuth();
  const puedePagar = tiene('COM_PAGAR_PROVEEDOR');
  const [filas, setFilas] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState(null);
  const [busqueda, setBusqueda] = useState('');
  const [sucursal, setSucursal] = useState('');
  const [estado, setEstado] = useState('pendientes');
  const [modal, setModal] = useState(null);

  const cargar = useCallback(async () => {
    setCargando(true);
    setError(null);
    try {
      setFilas(await listarCuentasPorPagar({ ...(sucursal ? { idSucursal: sucursal } : {}), estado }));
    } catch (err) {
      setError(err.message);
    } finally {
      setCargando(false);
    }
  }, [estado, sucursal]);

  useEffect(() => { cargar(); }, [cargar]);

  const visibles = useMemo(() => {
    const termino = busqueda.trim().toLocaleLowerCase('es');
    return filas.filter((factura) => [factura.proveedor, factura.num_factura, factura.sucursal]
      .some((valor) => String(valor ?? '').toLocaleLowerCase('es').includes(termino)));
  }, [filas, busqueda]);
  const vencidas = visibles.filter((factura) => factura.estado_pago !== 'PAGADO' && Number(factura.dias_vencida) > 0).length;

  const columnas = [
    {
      clave: 'fecha_vencimiento',
      titulo: 'Vencimiento',
      tipo: 'fecha',
      valorOrden: (factura) => factura.fecha_vencimiento,
      render: (factura) => (
        <div>
          {factura.fecha_vencimiento || '—'}
          <p className="text-body-sm text-fg-muted">Emisión {factura.fecha_emision}</p>
        </div>
      ),
    },
    {
      clave: 'proveedor',
      titulo: 'Proveedor',
      tipo: 'texto',
      valorOrden: (factura) => factura.proveedor,
      render: (factura) => (
        <div className="font-medium">
          {factura.proveedor}
          <p className="text-body-sm font-normal text-fg-muted">{factura.sucursal}</p>
        </div>
      ),
    },
    {
      clave: 'num_factura',
      titulo: 'Factura',
      tipo: 'texto',
      valorOrden: (factura) => factura.num_factura,
      render: (factura) => (
        <div>
          {factura.num_factura}
          <p className="text-body-sm text-fg-muted">
            {factura.tipo_costo === 'GASTO' ? 'Gasto' : 'Compra de insumos'}
          </p>
        </div>
      ),
    },
    {
      clave: 'total',
      titulo: 'Total',
      tipo: 'dinero',
      alinear: 'right',
      valorOrden: (factura) => factura.total,
      render: (factura) => dinero(factura.total),
    },
    {
      clave: 'pagado',
      titulo: 'Pagado',
      tipo: 'dinero',
      alinear: 'right',
      valorOrden: (factura) => factura.pagado,
      render: (factura) => dinero(factura.pagado),
    },
    {
      clave: 'saldo',
      titulo: 'Saldo',
      tipo: 'dinero',
      alinear: 'right',
      valorOrden: (factura) => factura.saldo,
      render: (factura) => <span className="font-semibold">{dinero(factura.saldo)}</span>,
    },
    {
      clave: 'estado_pago',
      titulo: 'Estado',
      tipo: 'texto',
      valorOrden: (factura) =>
        factura.estado_pago === 'PAGADO'
          ? 'Pagada'
          : Number(factura.dias_vencida) > 0
          ? `Vencida ${factura.dias_vencida}`
          : factura.estado_pago === 'PARCIAL'
          ? 'Pago parcial'
          : 'Pendiente',
      render: (factura) => <EstadoPago factura={factura} />,
    },
    ...(puedePagar
      ? [
          {
            clave: 'acciones',
            titulo: 'Acciones',
            alinear: 'right',
            ordenable: false,
            render: (factura) =>
              factura.estado_pago === 'PAGADO' ? (
                '—'
              ) : (
                <BotonIcono
                  icono={CreditCard}
                  etiqueta={`Pagar factura ${factura.num_factura}`}
                  titulo="Pagar factura"
                  onClick={() => setModal(factura)}
                />
              ),
          },
        ]
      : []),
  ];

  function pagoRegistrado() {
    setModal(null);
    setError(null);
    cargar();
  }

  return (
    <div className="space-y-6">
      <EncabezadoPagina seccion="Operación · Compras" titulo="Cuentas por pagar" descripcion="Consulta facturas y registra pagos a proveedores." />
      {error && <BannerError error={{ titulo: 'No se pudieron cargar las cuentas por pagar', mensaje: error, accion: '' }} />}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Metrica icono={FileText} cargando={cargando} valor={cargando ? null : visibles.length} etiqueta="Facturas mostradas" />
        <Metrica icono={AlertTriangle} tono={!cargando && vencidas > 0 ? 'peligro' : 'neutro'} cargando={cargando} valor={cargando ? null : vencidas} etiqueta="Facturas vencidas" />
        <Metrica icono={Building2} valor={usuario?.sucursales?.length ?? 0} etiqueta="Sucursales asignadas" />
      </div>
      <Card sinPadding className="overflow-hidden" icono={FileText} titulo="Facturas de proveedores" descripcion={cargando ? 'Filtra por estado, sucursal o escribe para buscar una factura.' : `${visibles.length} facturas`}>
        <div className="flex flex-wrap items-center gap-3 border-b border-line px-5 py-3">
          <div className="relative w-full max-w-xs">
            <Search size={16} strokeWidth={1.75} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-fg-subtle" aria-hidden="true" />
            <input className="input pl-9" aria-label="Buscar factura" placeholder="Proveedor, sucursal o factura" value={busqueda} onChange={(evento) => setBusqueda(evento.target.value)} />
          </div>
          <div className="w-full sm:w-44"><Select tamano="sm" aria-label="Estado de pago" value={estado} onChange={(evento) => setEstado(evento.target.value)} opciones={ESTADOS} /></div>
          <div className="w-full sm:w-56"><Select tamano="sm" aria-label="Sucursal" value={sucursal} onChange={(evento) => setSucursal(evento.target.value)} placeholder="Todas mis sucursales" opciones={(usuario?.sucursales ?? []).map((item) => ({ valor: String(item.id_sucursal), texto: item.nombre }))} /></div>
          {(busqueda || sucursal) && <Button variante="ghost" tamano="sm" onClick={() => { setBusqueda(''); setSucursal(''); }}>Limpiar filtros</Button>}
        </div>
        <Table
          cargando={cargando}
          filas={visibles}
          idFila="id_compra"
          vacio={<EstadoVacio icono={FileText} titulo={`No hay facturas ${estado === 'todas' ? '' : estado === 'pagadas' ? 'pagadas' : 'pendientes'} para estos filtros.`} />}
          columnas={columnas}
          idTabla="compras-cxp"
          ordenInicial={{ clave: 'fecha_vencimiento', direccion: 'asc' }}
        />
      </Card>
      {modal && <PagoDialogo factura={modal} cerrar={() => setModal(null)} onPagado={pagoRegistrado} />}
    </div>
  );
}
