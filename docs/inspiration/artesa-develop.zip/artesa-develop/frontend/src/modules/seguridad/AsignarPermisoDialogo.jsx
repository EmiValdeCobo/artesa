import { useState } from 'react';
import { Lock, X } from 'lucide-react';
import { api } from '../../api/client.js';
import Dialogo from '../../components/Dialogo.jsx';
import { useAlert } from '../../components/feedback/AlertProvider.jsx';
import { traducirError } from '../../errors/traducirError.js';
import Insignia from '../../components/branding/Insignia.jsx';
import { motivoBloqueoRevocar } from './rbac.js';

// Asigna o quita UN permiso a varios roles. Cada casilla se aplica al instante:
//   marcar   → POST   /seguridad/roles/:id/permisos/:idPermiso  (responde con los permisos del rol)
//   desmarcar → DELETE /seguridad/roles/:id/permisos/:idPermiso (204)
// Es la vista inversa de la matriz de la pestaña Roles (que guarda todo junto con PUT).
export default function AsignarPermisoDialogo({ permiso, roles, usuarioSesion, onCambio, onRolDesactualizado, onClose }) {
  const { notificar, notificarError } = useAlert();
  const [pendientes, setPendientes] = useState([]); // roles con una petición en curso

  const tiene = (rol) => rol.permisos.some((item) => item.id_permiso === permiso.id_permiso);

  const alternar = async (rol) => {
    if (pendientes.includes(rol.id_rol)) return;
    setPendientes((actuales) => [...actuales, rol.id_rol]);
    const asignado = tiene(rol);
    try {
      const ruta = `/seguridad/roles/${rol.id_rol}/permisos/${permiso.id_permiso}`;
      if (asignado) {
        await api.delete(ruta);
        onCambio(rol.id_rol, rol.permisos.filter((item) => item.id_permiso !== permiso.id_permiso));
        notificar.exito(`Permiso «${permiso.codigo}» quitado de ${rol.nombre}`);
      } else {
        const nuevosPermisos = await api.post(ruta, {});
        onCambio(rol.id_rol, nuevosPermisos);
        notificar.exito(`Permiso «${permiso.codigo}» asignado a ${rol.nombre}`);
      }
    } catch (err) {
      notificarError(err, { reintentar: () => alternar(rol) });
      const u = traducirError(err);
      // 404/409: el rol, el permiso o la asignación cambiaron en otra sesión → se vuelve a cargar todo.
      if (['ROL_NO_ENCONTRADO', 'PERMISO_NO_ENCONTRADO', 'ASIGNACION_DUPLICADA', 'ASIGNACION_NO_EXISTE'].includes(u.id)) onRolDesactualizado();
    } finally {
      setPendientes((actuales) => actuales.filter((id) => id !== rol.id_rol));
    }
  };

  return (
    <Dialogo tamano="md" labelledBy="asignar-titulo" describedBy="asignar-descripcion" onCerrar={onClose}>
      <div className="flex items-start justify-between gap-4 px-6 pt-6">
        <div className="min-w-0">
          <h2 id="asignar-titulo" className="text-h3">Asignar a roles</h2>
          <p id="asignar-descripcion" className="mt-1 text-body text-fg-muted">
            <span className="break-all font-mono text-body-sm">{permiso.codigo}</span> · Los cambios se aplican al instante.
          </p>
        </div>
        <button type="button" className="btn-ghost !p-2" onClick={onClose} aria-label="Cerrar"><X size={18} strokeWidth={1.75} aria-hidden="true" /></button>
      </div>

      <div className="space-y-4 px-6 py-5">
        <ul className="max-h-72 space-y-1.5 overflow-y-auto pr-1 scroll-fino" aria-label="Roles">
          {roles.map((rol) => {
            const asignado = tiene(rol);
            const ocupado = pendientes.includes(rol.id_rol);
            // Solo se bloquea QUITAR (anti-bloqueo); asignar siempre es seguro.
            const bloqueo = !rol.activo ? 'Rol inactivo: no se puede modificar.' : asignado ? motivoBloqueoRevocar(rol, permiso.codigo, usuarioSesion) : null;
            return (
              <li key={rol.id_rol}>
                <label className={`flex min-h-11 items-start gap-3 rounded-md border border-line px-3 py-2.5 text-body ${bloqueo ? 'bg-muted/60' : 'cursor-pointer hover:bg-muted'}`}>
                  <input type="checkbox" className="mt-0.5 h-4 w-4 shrink-0 accent-primary" checked={asignado} disabled={Boolean(bloqueo) || ocupado} onChange={() => alternar(rol)} />
                  <span className="min-w-0 flex-1">
                    <span className="flex flex-wrap items-center gap-2 font-medium">
                      {rol.nombre}
                      {rol.es_sistema && <Insignia>Sistema</Insignia>}
                      {ocupado && <span role="status" className="text-body-sm font-normal text-fg-muted">Guardando…</span>}
                    </span>
                    {bloqueo && <span className="mt-0.5 flex items-start gap-1 text-body-sm text-fg-muted"><Lock size={12} aria-hidden="true" className="mt-0.5 shrink-0" /> {bloqueo}</span>}
                  </span>
                </label>
              </li>
            );
          })}
        </ul>
      </div>

      <div className="flex flex-col-reverse gap-2 border-t border-line px-6 py-4 sm:flex-row sm:justify-end">
        <button type="button" className="btn-primary min-h-11 sm:min-h-10" onClick={onClose}>Listo</button>
      </div>
    </Dialogo>
  );
}
